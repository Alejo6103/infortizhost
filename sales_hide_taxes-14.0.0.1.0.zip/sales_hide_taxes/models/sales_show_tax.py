# -*- coding: utf-8 -*-
from odoo import models, fields


class show_tax_sales(models.TransientModel):
    _inherit = 'res.config.settings'

    group_sales_quatation_show_tax = fields.Boolean("Show Taxes", implied_group='sales_hide_taxes.group_sales_quatation_show_tax')
