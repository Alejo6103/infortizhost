# -*- coding: utf-8 -*-
{
    'name': 'Hide Taxes from Sale Order',
    'summary': "Hide/Show Taxes from Sale Ordes and Report",
    'description': "Hide/Show Taxes from Sale Ordes and Report",

    'author': 'iPredict IT Solutions Pvt. Ltd.',
    'website': 'http://ipredictitsolutions.com',
    'support': 'ipredictitsolutions@gmail.com',

    'category': 'Sales',
    'version': '14.0.0.1.0',
    'depends': ['sale_management'],

    'data': [
        'security/sales_show_tax_security.xml',
        'data/sale_quatation_show_tax.xml',
        'views/sales_quatation_show_tax.xml',
        'views/res_config_setting_view.xml',
        'views/report_sales_show_tax.xml',
    ],

    'license': "OPL-1",
    'price': 8,
    'currency': "EUR",

    'auto_install': False,
    'installable': True,

    'images': ['static/description/banner.png'],
    'pre_init_hook': 'pre_init_check',
}
